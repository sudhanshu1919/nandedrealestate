const markers = [
    { position: [19.194529898787334, 77.27977355990448], data: { id: 1, name: 'Horizon1 Aprtment',address:'Shree Nagar, Nanded',rate:"35,00000",area:"600sqft" } },
    { position: [19.194529898787334, 77.29977355990448], data: { id: 2, name: 'Park2 Avenue Aprtment',address:'Near Dmart, Nanded',rate:"55,45000",area:"700sqft" } },
    { position: [19.197529898787334, 77.29977355990448], data: { id: 2, name: 'Sai3 Metro Aprtment' ,address:'Bhavsar Chouk, Nanded',rate:"22,00000",area:"670sqft"} },
    { position: [19.194529898787334, 77.27977355990448], data: { id: 1, name: 'Horizon4 Aprtment',address:'Shree Nagar, Nanded',rate:"35,00000",area:"600sqft" } },
    { position: [19.194529898787334, 77.29977355990448], data: { id: 2, name: 'Park5 Avenue Aprtment',address:'Near Dmart, Nanded',rate:"55,45000",area:"700sqft" } },
    { position: [19.197529898787334, 77.29977355990448], data: { id: 2, name: 'Sai6 Metro Aprtment' ,address:'Bhavsar Chouk, Nanded',rate:"22,00000",area:"670sqft"} },
    { position: [19.194529898787334, 77.29977355990448], data: { id: 2, name: 'Park7 Avenue Aprtment',address:'Near Dmart, Nanded',rate:"55,45000",area:"700sqft" } },
    { position: [19.197529898787334, 77.29977355990448], data: { id: 2, name: 'Sai8 Metro Aprtment' ,address:'Bhavsar Chouk, Nanded',rate:"22,00000",area:"670sqft"} },
  
  ];

  export default markers;